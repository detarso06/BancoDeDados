--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: foodss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.foodss (
    id integer NOT NULL,
    tipo character varying(100),
    quantidade_em_estoque integer,
    preco numeric(10,2),
    validade date,
    fornecedor character varying(100)
);


ALTER TABLE public.foodss OWNER TO postgres;

--
-- Name: foodss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.foodss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.foodss_id_seq OWNER TO postgres;

--
-- Name: foodss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.foodss_id_seq OWNED BY public.foodss.id;


--
-- Name: immunizationss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.immunizationss (
    id integer NOT NULL,
    tipo character varying(100),
    estoque integer,
    aplicador character varying(100),
    seringas integer,
    descricao character varying(365)
);


ALTER TABLE public.immunizationss OWNER TO postgres;

--
-- Name: immunizationss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.immunizationss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.immunizationss_id_seq OWNER TO postgres;

--
-- Name: immunizationss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.immunizationss_id_seq OWNED BY public.immunizationss.id;


--
-- Name: ownerss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ownerss (
    id integer NOT NULL,
    email character varying(100),
    nome character varying(100),
    telefone character varying(100),
    endereco character varying(100)
);


ALTER TABLE public.ownerss OWNER TO postgres;

--
-- Name: ownerss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ownerss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ownerss_id_seq OWNER TO postgres;

--
-- Name: ownerss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ownerss_id_seq OWNED BY public.ownerss.id;


--
-- Name: pet_foodd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pet_foodd (
    pet_id integer NOT NULL,
    food_id integer NOT NULL,
    quantidade_consumida integer
);


ALTER TABLE public.pet_foodd OWNER TO postgres;

--
-- Name: pet_vaccinee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pet_vaccinee (
    pet_id integer NOT NULL,
    vaccine_id integer NOT NULL,
    data_aplicacao date
);


ALTER TABLE public.pet_vaccinee OWNER TO postgres;

--
-- Name: petss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.petss (
    id integer NOT NULL,
    nome character varying(100),
    tipo character varying(100),
    raca character varying(100),
    pelo character varying(100),
    tutor_id integer
);


ALTER TABLE public.petss OWNER TO postgres;

--
-- Name: petss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.petss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.petss_id_seq OWNER TO postgres;

--
-- Name: petss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.petss_id_seq OWNED BY public.petss.id;


--
-- Name: toyss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.toyss (
    id integer NOT NULL,
    tipo character varying(100),
    estoque integer,
    categoria_animal character varying(100),
    preco numeric(10,2),
    descricao character varying(100)
);


ALTER TABLE public.toyss OWNER TO postgres;

--
-- Name: toyss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.toyss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.toyss_id_seq OWNER TO postgres;

--
-- Name: toyss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.toyss_id_seq OWNED BY public.toyss.id;


--
-- Name: foodss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.foodss ALTER COLUMN id SET DEFAULT nextval('public.foodss_id_seq'::regclass);


--
-- Name: immunizationss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immunizationss ALTER COLUMN id SET DEFAULT nextval('public.immunizationss_id_seq'::regclass);


--
-- Name: ownerss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ownerss ALTER COLUMN id SET DEFAULT nextval('public.ownerss_id_seq'::regclass);


--
-- Name: petss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petss ALTER COLUMN id SET DEFAULT nextval('public.petss_id_seq'::regclass);


--
-- Name: toyss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.toyss ALTER COLUMN id SET DEFAULT nextval('public.toyss_id_seq'::regclass);


--
-- Data for Name: foodss; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.foodss (id, tipo, quantidade_em_estoque, preco, validade, fornecedor) FROM stdin;
\.
COPY public.foodss (id, tipo, quantidade_em_estoque, preco, validade, fornecedor) FROM '$$PATH$$/4897.dat';

--
-- Data for Name: immunizationss; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.immunizationss (id, tipo, estoque, aplicador, seringas, descricao) FROM stdin;
\.
COPY public.immunizationss (id, tipo, estoque, aplicador, seringas, descricao) FROM '$$PATH$$/4899.dat';

--
-- Data for Name: ownerss; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ownerss (id, email, nome, telefone, endereco) FROM stdin;
\.
COPY public.ownerss (id, email, nome, telefone, endereco) FROM '$$PATH$$/4893.dat';

--
-- Data for Name: pet_foodd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pet_foodd (pet_id, food_id, quantidade_consumida) FROM stdin;
\.
COPY public.pet_foodd (pet_id, food_id, quantidade_consumida) FROM '$$PATH$$/4903.dat';

--
-- Data for Name: pet_vaccinee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pet_vaccinee (pet_id, vaccine_id, data_aplicacao) FROM stdin;
\.
COPY public.pet_vaccinee (pet_id, vaccine_id, data_aplicacao) FROM '$$PATH$$/4902.dat';

--
-- Data for Name: petss; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.petss (id, nome, tipo, raca, pelo, tutor_id) FROM stdin;
\.
COPY public.petss (id, nome, tipo, raca, pelo, tutor_id) FROM '$$PATH$$/4895.dat';

--
-- Data for Name: toyss; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.toyss (id, tipo, estoque, categoria_animal, preco, descricao) FROM stdin;
\.
COPY public.toyss (id, tipo, estoque, categoria_animal, preco, descricao) FROM '$$PATH$$/4901.dat';

--
-- Name: foodss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.foodss_id_seq', 3, true);


--
-- Name: immunizationss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.immunizationss_id_seq', 3, true);


--
-- Name: ownerss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ownerss_id_seq', 3, true);


--
-- Name: petss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.petss_id_seq', 3, true);


--
-- Name: toyss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.toyss_id_seq', 3, true);


--
-- Name: foodss foodss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.foodss
    ADD CONSTRAINT foodss_pkey PRIMARY KEY (id);


--
-- Name: immunizationss immunizationss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immunizationss
    ADD CONSTRAINT immunizationss_pkey PRIMARY KEY (id);


--
-- Name: ownerss ownerss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ownerss
    ADD CONSTRAINT ownerss_pkey PRIMARY KEY (id);


--
-- Name: pet_foodd pet_foodd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_foodd
    ADD CONSTRAINT pet_foodd_pkey PRIMARY KEY (pet_id, food_id);


--
-- Name: pet_vaccinee pet_vaccinee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_vaccinee
    ADD CONSTRAINT pet_vaccinee_pkey PRIMARY KEY (pet_id, vaccine_id);


--
-- Name: petss petss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petss
    ADD CONSTRAINT petss_pkey PRIMARY KEY (id);


--
-- Name: toyss toyss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.toyss
    ADD CONSTRAINT toyss_pkey PRIMARY KEY (id);


--
-- Name: pet_foodd pet_foodd_food_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_foodd
    ADD CONSTRAINT pet_foodd_food_id_fkey FOREIGN KEY (food_id) REFERENCES public.foodss(id) ON DELETE CASCADE;


--
-- Name: pet_foodd pet_foodd_pet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_foodd
    ADD CONSTRAINT pet_foodd_pet_id_fkey FOREIGN KEY (pet_id) REFERENCES public.petss(id) ON DELETE CASCADE;


--
-- Name: pet_vaccinee pet_vaccinee_pet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_vaccinee
    ADD CONSTRAINT pet_vaccinee_pet_id_fkey FOREIGN KEY (pet_id) REFERENCES public.petss(id) ON DELETE CASCADE;


--
-- Name: pet_vaccinee pet_vaccinee_vaccine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pet_vaccinee
    ADD CONSTRAINT pet_vaccinee_vaccine_id_fkey FOREIGN KEY (vaccine_id) REFERENCES public.immunizationss(id) ON DELETE CASCADE;


--
-- Name: petss petss_tutor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.petss
    ADD CONSTRAINT petss_tutor_id_fkey FOREIGN KEY (tutor_id) REFERENCES public.ownerss(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

